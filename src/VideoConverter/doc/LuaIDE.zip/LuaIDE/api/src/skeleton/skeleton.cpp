// skeleton.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "skeleton.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


// IDE and interpreter calls this function when loading dll
// register lua data here
SKELETON_API int LuaRegister(lua_State* L, HWND hWnd)
{
	// init api library
	// call this when you want to use library functions
	InitLibAPI(hWnd);

	// uncomment this to attach DOS console to process (stdin, stdout, stderr)
	// AttachConsole();

	// do any lua_register here 
	// for examples look into stdlib source

	return 0;
}


