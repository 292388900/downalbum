#include "StdAfx.h"
#include "LocalFile.h"

CLocalFile::CLocalFile(const char * name)
{
	assert(NULL != name);
	assert(0 != name[0]);

	m_fd = CreateFileA(name, GENERIC_READ,
						FILE_SHARE_READ, NULL,
						OPEN_EXISTING,
						FILE_ATTRIBUTE_NORMAL, NULL);
	if (INVALID_HANDLE_VALUE == m_fd) {
		printf("Open file %s failed, error: %d!\n",name, GetLastError());
		return ;
	}

	m_size = GetFileSize(m_fd, NULL);
	return;
}

CLocalFile::~CLocalFile(void)
{
	if (NULL != m_fd) {
		CloseHandle(m_fd);
	}
}

int CLocalFile::Read(size_t offset,
					 size_t size,
					 void * pBuf)
{
	DWORD ret;
	ULONG rdsize;

	ret = SetFilePointer(m_fd, offset, NULL, FILE_BEGIN);
	if (INVALID_SET_FILE_POINTER == ret) {
		ret = GetLastError();
		printf("Seek file failed, error: %d!\n", ret);
		return ret;
	}

	if (!ReadFile(m_fd, pBuf, size, &rdsize, NULL)) {
		ret = GetLastError();
		printf("Read file failed, error: %d\n", ret);
		return ret;
	}

	return 0;
}