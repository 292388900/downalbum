// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>



// TODO: reference additional headers your program requires here
#include <assert.h>
#include <windows.h>
#include <Psapi.h>

#include <malloc.h>


typedef struct {
	int sections;
	int imageBase;
	int entryPoint;
	int imageSize;
	int exRva;
	int exSize;
	int imRva;
	int imSize;
	int resRva;
	int resSize;
	int relocRva;
	int relocSize;
	int dbgRva;
	int dbgSize;
	int offsetSection;
	int fileType;
}PeInfo;

void DumpPeInfo(PeInfo *pInfo);