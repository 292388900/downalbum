#pragma once

class CLocalFile
{
public:
	CLocalFile(const char * name);
	~CLocalFile(void);

	int Read(size_t offset, size_t size, void *ppBuf);

    size_t GetSize() const { return m_size;}

private:
	HANDLE           m_fd;
    size_t			m_size;
};
