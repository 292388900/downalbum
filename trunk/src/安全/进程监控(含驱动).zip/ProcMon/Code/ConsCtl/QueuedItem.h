//---------------------------------------------------------------------------
//
// QueuedItem.h
//
// SUBSYSTEM: 
//				
// MODULE:    
//
// DESCRIPTION:
//
// AUTHOR:		Ivo Ivanov
//                                                                         
//---------------------------------------------------------------------------
#if !defined(_QUEUEDITEM_H_)
#define _QUEUEDITEM_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#endif // !defined(_QUEUEDITEM_H_)
//----------------------------End of the file -------------------------------