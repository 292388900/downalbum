Lua 5.1.3 + minor modification to the Lua state struct (lua_State) in lstate.h
(added void* user_param)
